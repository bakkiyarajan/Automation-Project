package com.kors.steps;

import com.kors.pages.MultipleLanguagePage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class MultipleLanguagePageSteps {
    MultipleLanguagePage multipleLanguage = new MultipleLanguagePage();

    @Given ( "^user on home page$" )
    public void userOnHomePage() {
    }

    @And ( "^User click on country selector image$" )
    public void userClickOnCountrySelectorImage() throws InterruptedException {
            multipleLanguage.clickOnCountrySelector();
        }


    @Then ( "^user should print  all the country which is having more than one language$" )
    public void userShouldPrintAllTheCountryWhichIsHavingMoreThanOneLanguage() throws InterruptedException {
        multipleLanguage.multipleLanguageSelection();
    }

}


