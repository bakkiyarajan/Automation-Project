package com.kors.steps;

import com.kors.pages.SortingPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class SortingPageStep {
    SortingPage soringPage =new SortingPage();
    @And ( "^user mouse hover on HandBags menu and select View All Handbags menu$" )
    public void userMouseHoverOnHandBagsMenuAndSelectViewAllHandbagsMenu() {

    }

    @And ( "^user select the sorting order High to low$" )
    public void userSelectTheSortingOrderHighToLow() {
    }

    @Then ( "^user should see the product in selected oder$" )
    public void userShouldSeeTheProductInSelectedOder() {
        soringPage.handbagList();
    }




}
