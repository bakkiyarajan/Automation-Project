package com.kors.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

import static com.kors.utils.ConfigUtils.getPropertyByKey;
import static com.kors.utils.ConfigUtils.loadProperties;


public class DriverUtils {
   public static WebDriver driver;

    public static void initDriver() {
        loadProperties();
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Osiris\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");

        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(getPropertyByKey("application.url"));
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        if(driver.findElements(By.xpath("//*[contains(text(),'ACCEPT ALL ')]")).size()!=0)
        {
            driver.findElement(By.xpath("//*[contains(text(),'ACCEPT ALL ')]")).click();
        }

    }



    public static WebDriver getDriver() {

        if (driver == null ) {
            initDriver();
        }
        return driver;
    }

    public static void tearDown() {
        driver.quit();
        driver = null;
    }
}
