package com.kors.pages;

import com.kors.utils.DriverUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.List;

public class SortingPage extends DriverUtils {

    public void handbagList() {
        driver.findElement(By.xpath("//a[@title=('Handbags')][@aria-label='Handbags main.nav.keyboardGuide']")).sendKeys(Keys.ENTER);
        driver.findElement(By.xpath("//button[contains(text(),'Featured')]/span")).click();
        Actions actions = new Actions(driver);
        WebElement abc = driver.findElement(By.xpath("//button[contains(text(),'Featured')]/span"));
        actions.moveToElement(abc);
        actions.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'price high to low')]"))).click().perform();
        WebElement handBagList = driver.findElement(By.xpath("//*[@id=\"pageBodyWrapper\"]/div/div[3]/div/main/div[3]"));
        List<WebElement> handBagDetailsList = handBagList.findElements(By.tagName("ul"));
        for (WebElement li : handBagDetailsList) {

            System.out.println(li.getText());

            System.out.println("--------------------------");
        }

    }
}



