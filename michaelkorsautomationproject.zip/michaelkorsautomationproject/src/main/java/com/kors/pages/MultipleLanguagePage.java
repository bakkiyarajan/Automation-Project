package com.kors.pages;

import com.kors.utils.DriverUtils;
import org.openqa.selenium.*;

import java.util.ArrayList;
import java.util.List;


public class MultipleLanguagePage extends DriverUtils {
    WebElement selectorImg = driver.findElement(By.xpath("//*[contains(text(),'UK £')]"));

    public void clickOnCountrySelector() throws InterruptedException {
        selectorImg.click();
    }

    public void multipleLanguageSelection() throws InterruptedException {
        WebElement handBagList = driver.findElement(By.xpath("//*[@id=\"react-aria-modal-dialog\"]/div/div[2]\n"));
        List<WebElement> allLinks = handBagList.findElements(By.tagName("a"));
        String country = "";
        List<String> langList = new ArrayList<>();
        System.out.println("The list of country morethan 1 language");
        for (WebElement link : allLinks) {
            if (link.getText() != null && !link.getText().isEmpty()) {

                if (langList.size() != 0) {
                    if (langList.size() > 1)

                        System.out.println("Country Name :" + country + " langList : " + langList);

                }

                country = link.getText();
                langList = new ArrayList<>();
            } else {
                if (!langList.contains(link.getAttribute("title"))) {
                    langList.add(link.getAttribute("title"));
                }
            }


        }


    }

}



